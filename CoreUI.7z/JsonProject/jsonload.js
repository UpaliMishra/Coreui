var myApp  =  angular.module('myApp', []);

myApp.run(function($http) {

$http.defaults.headers.common['Access-Control-Allow-Origin'] = '*';
$http.defaults.headers.common['Access-Control-Allow-Headers']='X-Requested-With,content-type';
$http.defaults.headers.common['Access-Control-Allow-Credentials']='true';
});

myApp.filter("Active", function(){
    return function(Active){
        switch(Active){
         case $scope.active="Y":
             return value='1';

             case $scope.active= "N":
                return value='0';

        }
    }
})




myApp.controller('jsonCtrl', function($scope, $http){
//	$http.get('http://dummy.restapiexample.com/api/v1/employees').success(function (data){
//		$scope.employees = data.data;
//
$http.get('customers.json').success(function (data){
   // $scope.employees = data;

  
   for (attribute in data.attributes){
    


    if (attribute.key == null)
        data.attributes[attribute].key = "abc";
    else
    data.attributes[attribute].key="123";
    $scope.customers = data.attributes;
}


var employee =[
    {firstName:'David',lastName:'AZV',Gender:'Male',Salary:550000},
    {firstName:'David',lastName:'AZV',Gender:'Male',Salary:550000},
    {firstName:'David',lastName:'AZV',Gender:'Male',Salary:550000}
];

$scope.YES = function(){
    $scope.active="Y";

}
$scope.NO = function(){
    $scope.active="N";

}



//$scope.employees=  [];   

$scope.addEmp = function(){
        //var  emp;
        //$scope.employees.push({ uuid:$scope.uuid, username:$scope.username, dispName:$scope.dispName
        //});

        var  emp;
        $scope.customers.push({  name:$scope.name, dispName:$scope.dispName,    active:$scope.active
        });

        
 


     //   $http.post('http://dummy.restapiexample.com/api/v1/create',emp).success(function (data){
      //      alert('successfully uploaded');
        //});

    }
    


  
});
});  
 
        
   
    


